// JavaScript Document	
var currentLang = 'es';
moment.locale(currentLang);
//http://momentjs.com/

function darFechaHoyToIso(){
	var fechaHoy = new Date();
	return fechaHoy.toISOString();
}

function darFechaHoyMasDiasToIso(cantidadDias ){
	var currentDate = new Date()
	//moment("12-25-1995", "MM-DD-YYYY");
	
	var day = currentDate.getDate() + cantidadDias;
	var month = currentDate.getMonth() + 1;
	var year = currentDate.getFullYear() ;
	//var m = moment(currentDate);
	var m = moment(day + "/" + month + "/" + year, "DD/MM/YYYY");
	//var fecha = day + "/" + month + "/" + year;
	fecha = m.format();
	//alert(fecha);
	return fecha;
}


function darFechaHoyMasDias(cantidadDias ){
	var currentDate = new Date()
	//moment("12-25-1995", "MM-DD-YYYY");
	
	var day = currentDate.getDate() + cantidadDias;
	var month = currentDate.getMonth() + 1;
	var year = currentDate.getFullYear() ;
	//var m = moment(currentDate);
	var m = moment(day + "/" + month + "/" + year, "DD/MM/YYYY");
	//var fecha = day + "/" + month + "/" + year;
	fecha = m.format('dddd D [de] MMMM YYYY');

	return fecha;
}


