// JavaScript Document	
//http://stackoverflow.com/questions/391979/get-client-ip-using-just-javascript
var mmjsCountryCode = geoip_country_code();
var mmjsCountryName = geoip_country_name();

var storage = new Storage();





$(document).ready(function() {
	
	});



$(document ).on( "pageshow", "#usuario_1", function() {
	
	//alert("Hola");
	
	$("#formLogin").on("click", "#iniciarSesion", function (event) {
		//alert("Hola 2");
		buscarGrupoFamiliar('#formLogin','#resultadoGrupoFamiliar',storage);
		
		});
	
		
		
});


$(document ).on( "pageshow", "#usuario_2", function() {
	
	
	//buscarGrupoFamiliar('#formLogin','#resultadoGrupoFamiliar',storage);
	//alert(storage.getIdUsuarioPrincipal());
	
//	$("#usuario_2").on("click", ".selusuario", function (event) {
//		id = $(event.target).attr("id");
//		buscarUsuario(storage,id);
//		});
	
		
		
});

$(document ).on( "pagecreate", "#usuario_2", function() {
	//alert("pagecreate #usuario_2");
	$("#usuario_2").on("click", ".selusuario", function (event) {
		id = $(event.target).attr("id");
		buscarUsuario(storage,id);
		});
});
$(document ).on( "pageshow", "#usuario_3", function() {
	elusu = null;
	if(storage.getIdUsuarioAModificar() != null){
		elusu = storage.getUsuarioModifica(storage.getIdUsuarioAModificar());
	}
	
	
	if(elusu != null) {
		$("#formRegistro_3 input").each(function (index) {
			 $(this).val(elusu[$(this).attr("id")])
				//alert($(this).attr("id"));
		 });
		 
		 $("#ingresoemail").val(elusu.correo);
		 $("#ingresoemailconfirma").val(elusu.correo);
		 
		 $('#password').attr('value')
		 
		 $("#formRegistro_3 select").each(function (index) {
				//alert($(this).attr("id")+" |"+elusu[$(this).attr("id")]+"|");
				
			// $(this).val(elusu[$(this).attr("id")])
			 $(this).val(elusu[$(this).attr("id")]).attr('selected', true).siblings('option').removeAttr('selected'); 
			 $(this).selectmenu("refresh",true);
			
		 });
	}
//	 $("#guardarTitular").click(function(e) {
//		valida = true;
//		 $("#formRegistro_3.requerido").each(function (index) {
//			             // $(this).removeClass();
//			              //$(this).addClass("parrafo");
//			 //alert($(this).val()+"|"+$(this).attr("id"));
//			 if($(this).val()==''){
//				 valida = false;
//				 $(this).addClass("error")
//			 } else{
//				 $(this).removeClass()
//				  $(this).addClass("requerido")
//			 }
//		 });
//		if(!valida){
//			alert("Complete todos los campos que contienen '*'");
//		} else {
//			guardarUsuario('#formRegistro_3','');	
//		}
//	 });
		
		
});

$(document ).on( "pagecreate", "#usuario_3", function() {
	
	 $("#guardarTitular").click(function(e) {
		valida = true;
		 $("#formRegistro_3.requerido").each(function (index) {
			 if($(this).val()==''){
				 valida = false;
				 $(this).addClass("error")
			 } else{
				 $(this).removeClass()
				  $(this).addClass("requerido")
			 }
		 });
		if(!valida){
			alert("Complete todos los campos que contienen '*'");
		} else {
			guardarUsuario('#formRegistro_3','#usuario_1');	
		}
	 });
		
		
});


$(document ).on( "pageshow", "#usuario_3adicional", function() {
	
	//$('#formRegistro_3_adicional input').not('[type="button"]').val(''); // clear inputs except buttons, setting value to blank
    //$('#formRegistro_3_adicional select').val(''); // clear select
    //$('#formRegistro_3_adicional textarea').val(''); // set text area value to blank
    //$('#formRegistro_3_adicional').each (function(){ this.reset(); });
    //$("#formRegistro_3_adicional select").selectmenu('refresh', true);
	//$("#formRegistro_3_adicional")[0].reset()
	$('#formRegistro_3_adicional').trigger("reset");
	//$("#formRegistro_3_adicional #idusuario")[0].reset();
	$('#formRegistro_3_adicional #idusuario').val('');
	elusu = null;
	if(storage.getIdUsuarioAModificar() != null){
		elusu = storage.getUsuarioModifica(storage.getIdUsuarioAModificar());
	}
	
	
	if(elusu != null) {
		$("#formRegistro_3_adicional input").each(function (index) {
			 $(this).val(elusu[$(this).attr("id")])
				//alert($(this).attr("id"));
		 });
		 
		 
		 $("#formRegistro_3_adicional select").each(function (index) {
			 $(this).val(elusu[$(this).attr("id")]).attr('selected', true).siblings('option').removeAttr('selected'); 
			 $(this).selectmenu("refresh",true);
			
		 });
	}
	$("#formRegistro_3_adicional #idusuarioprincipal").val(storage.getIdUsuarioPrincipal());
	
	alert(storage.getIdUsuarioPrincipal());
//	 $("#guardarAdicional").click(function(e) {
//		valida = true;
//		 $("#formRegistro_3_adicional.requerido").each(function (index) {
//			             // $(this).removeClass();
//			              //$(this).addClass("parrafo");
//			 //alert($(this).val()+"|"+$(this).attr("id"));
//			 if($(this).val()==''){
//				 valida = false;
//				 $(this).addClass("error")
//			 } else{
//				 $(this).removeClass()
//				  $(this).addClass("requerido")
//			 }
//		 });
//		if(!valida){
//			alert("Complete todos los campos que contienen '*'");
//		} else {
//			guardarUsuario('#formRegistro_3_adicional','');	
//		}
//	 });
//		
		
});

$(document ).on( "pagecreate", "#usuario_3adicional", function() {
	alert("pagecreate #usuario_3adicional")
    $("#guardarAdicional").click(function(e) {
		valida = true;
		 $("#formRegistro_3_adicional.requerido").each(function (index) {
			             // $(this).removeClass();
			              //$(this).addClass("parrafo");
			 //alert($(this).val()+"|"+$(this).attr("id"));
			 if($(this).val()==''){
				 valida = false;
				 $(this).addClass("error")
			 } else{
				 $(this).removeClass()
				  $(this).addClass("requerido")
			 }
		 });
		if(!valida){
			alert("Complete todos los campos que contienen '*'");
		} else {
			guardarUsuario('#formRegistro_3_adicional','#usuario_2');	
		}
	 });
});




$(document).on("pageshow",".air",function(){
	caargarEstructuraPagina($(this));
	$(document).ready(function(){
		$('#mpreservas_1').on("click",function(){
			$( ":mobile-pagecontainer" ).pagecontainer('change', 'reservas_1.html', {
				reverse: false,
				reload: true
	 
			});
		});
	}); ////$(document).ready(function()
		

			
});

$( document ).on( "pagecreate", "#itinerarios", function() {
//var thePage = $(this);
	var thePage = $(this);
	buscarCiudades("Origen","#origen","OriginLocation");  
	buscarCiudades("Destino","#destino","DestinationLocation");  
	$('#DepartureDateTime').val(darFechaHoyToIso());
	//alert("pagebeforecreate");
		$('#itinerarioBuscar').on("click",function(){
			if($('#OriginLocation').val() == $('#DestinationLocation').val()){
				alert(' El aeropuerto de Origen y Destino no pueden ser el mismo.');
			} else {
				$('#DepartureDateTime').val(darFechaHoyToIso());
				buscarVuelos('#formItinerario','#resultadoBusqueda',true);
			}
	});
});

$( document ).on( "pagecreate", "#reservas_1", function() {
	var thePage = $(this);
	$(document).ready(function(){
		$('#breserva_1').on("click",function(){
			$( ":mobile-pagecontainer" ).pagecontainer('change', '#reservas_2', {
					reverse: false,
					reload: true
				});
		});
	}); ////$(document).ready(function()
});
$( document ).on( "pageshow", "#reservas_1", function() {
	var thePage = $(this);
	   //alert("pageshow");
		buscarCiudades("Origen","#resorigen","OriginLocation");  
		buscarCiudades("Destino","#resdestino","DestinationLocation");  
		 $('#ArrivalDateTime').val(darFechaHoyMasDias(1));
		 $("#DepartureDateTime" ).val(darFechaHoyMasDias(1));
});
$( document ).on( "pageshow", "#reservas_2", function() {
	var page = $(this);
	//$('#OriginLocation').val("CCS");
	//$('#DestinationLocation').val("MAR");
	origen = $('#OriginLocation').val();
	destino = $('#DestinationLocation').val();
	mostrarInformacionSeleccionadaPantallaUno(page);
	
	$('#DepartureDateTime').val(darFechaHoyMasDiasToIso(2));
	buscarVuelos('#formReservas','#resultadoSalidaBusqueda',true);
	 $('#OriginLocation').val(destino);
	 $('#DestinationLocation').val(origen);
	$('#ArrivalDateTime').val(darFechaHoyMasDiasToIso(2));
	buscarVuelos('#formReservas','#resultadoRetornoBusqueda',false);
	
	$("#reservas_2").on("click", ".selVuelo", function (event) {
		idVuelo = $(event.target).attr("id").split("_")[1];
		divcontent = $(event.target).attr("id").split("_")[0];
		vueloSeleccionado = storage.getVueloById(idVuelo);
		vueloSalida = true;
		if(divcontent == "#resultadoRetornoBusqueda"){
			vueloSalida = false;
		}
		buscarVueloTarifas(page,$(event.target).attr("id"),'#formReservas',vueloSeleccionado,"ponerEn",vueloSalida,storage);

		
		});
	
	
});
$( document ).on( "pagecreate", "#reservas_2", function() {
	var page = $(this);
	
    $('#breservas_2').on("click",function(){
    	//alert("sss"+$('#formReservas').serialize());
    	//$('#formReservas').serialize();
    	
	 $( ":mobile-pagecontainer" ).pagecontainer('change', 'usuario_1.html', {
		  transition: 'flip',
		  reverse: false,
		  reload: true
		 
		});
	});
});

$( document ).on( "pageshow", "#home", function() {
	var thePage = $(this);
	   //alert("pageshow" + $(this));
		//buscarCiudades("Origen","#origen","OriginLocation");  
		//buscarCiudades("Destino","#destino","DestinationLocation");  
	//caargarEstructuraPagina($(this));
		

	
});




