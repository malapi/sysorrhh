function geoip_country_code() {
    return 'AR'
}
function geoip_country_name() {
    return 'Argentina'
}
function geoip_city() {
    return 'Neuquen'
}
function geoip_region() {
    return '15'
}
function geoip_region_name() {
    return 'Neuquen'
}
function geoip_latitude() {
    return '-38.9500'
}
function geoip_longitude() {
    return '-68.0667'
}
function geoip_postal_code() {
    return '8300'
}
function geoip_area_code() {
    return '0'
}
function geoip_metro_code() {
    return '0'
}
