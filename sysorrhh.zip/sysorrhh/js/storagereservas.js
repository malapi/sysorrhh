var Storage = function() {
    this.arrVuelosSalida=null;
    this.arrVuelosRetorno=null;
    this.vueloSalida = null;
    this.vueloRetorno = null;
    this.vueloSalidaTarifa = null;
    this.vueloRetornoTarifa = null;
    this.usuariomodifica = null;
    this.idusuarioamodificar=null;
    this.idusuarioprincipal=null;
}

$.extend(Storage.prototype, {
    setVuelosSalida: function(obj){
    	this.arrVuelosSalida = obj;
    },
    getVuelosSalida:function(){
    	return this.arrVuelosSalida;
    },
    setVuelosRetorno: function(obj){
    	this.arrVuelosRetorno = obj;
    },
    getVuelosRetorno:function(){
    	return this.arrVuelosRetorno;
    },
    getVueloSalida:function(){
    	return this.vueloSalida;
    },
    setVueloSalida:function(obj){
    	this.vueloSalida = obj;
    },
    getVueloRetorno:function(){
    	return this.vueloRetorno;
    },
    setVueloRetorno:function(obj){
    	this.vueloRetorno = obj;
    },
    getVueloSalidaTarifa:function(){
    	return this.vueloSalidaTarifa;
    },
    setVueloSalidaTarifa:function(obj){
    	this.vueloSalidaTarifa = obj;
    },
    getVueloRetornoTarifa:function(){
    	return this.vueloRetornoTarifa;
    },
    setVueloRetornoTarifa:function(obj){
    	this.vueloRetornoTarifa = obj;
    },
    setUsuarioModifica: function(obj){
    	this.usuariomodifica = obj;
    },
    getIdUsuarioAModificar:function(){
    	return this.idusuarioamodificar;
    },
    setIdUsuarioAModificar:function(obj){
    	this.idusuarioamodificar = obj;
    },
    getIdUsuarioPrincipal:function(){
    	return this.idusuarioprincipal;
    },
    setIdUsuarioPrincipal:function(obj){
    	this.idusuarioprincipal = obj;
    },
    getUsuarioModifica:function(){
    	usuario = null;
    	if(this.usuariomodifica != null){
    		$.each(this.usuariomodifica, function( key, value ) {
    			if(id == value.idusuario){
    				usuario =  value;
    				return false;
    			}
			});
    	
    	
    	
    	}
    	return usuario;
    },
    getVueloById:function(id){
    	vueloId = null;
    	if(this.arrVuelosSalida != null){
    		$.each(this.arrVuelosSalida, function( key, value ) {
    			if(id == value.FlightNumber){
    				vueloId =  value;
    				return false;
    			}
			});
    		if(vueloId == null){
        		$.each(this.arrVuelosRetorno, function( key, value ) {
        			if(id == value.FlightNumber){
        				vueloId =  value;
        				return false;
        			}
    			});	
    		}
			
    		return vueloId;
    	}
    },
    getTarifaVuelo:function(elDeSalida){
    	vueloTarifa = null;
    	 impTax=0;
    	if(elDeSalida){
    		if(this.getVueloSalidaTarifa() != null){
        		$.each(this.getVueloSalidaTarifa(), function( indice, vuelosTax ) {
        			$.each(vuelosTax, function( key, value ) {
        				impTax +=parseFloat(value.Amount);
        				vueloTarifa =  value;
        				vueloTarifa.Amount = impTax;
        			});
        				return false;
        		});
    		}
    	}else{
    		if(this.getVueloRetornoTarifa() != null){
        		$.each(this.getVueloRetornoTarifa(),  function( indice, vuelosTax ) {
        			$.each(vuelosTax, function( key, value ) {
        				impTax +=parseFloat(value.Amount);
        				vueloTarifa =  value;
        				vueloTarifa.Amount = impTax;
        			});
        				return false;
        			
    			});
    	}
    		
    		
    }
      	return vueloTarifa;
    }
});


