// JavaScript Document	
//http://stackoverflow.com/questions/391979/get-client-ip-using-just-javascript
//var mmjsCountryCode = geoip_country_code();
//var mmjsCountryName = geoip_country_name();
$(document).ready(function() {
	
	});

$(document).on("pageshow",".air",function(){
	caargarEstructuraPagina($(this));
			
});


