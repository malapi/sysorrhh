
//var serviceurl = "http://sapsoluciones.com.ar/app/html5aerolineas/ravsaphp/wsdl/"
//var serviceurlusu = "http://sapsoluciones.com.ar/app/html5aerolineas/aerolineaphp/operaciones/"
var serviceurl = "http://127.0.0.1/ravsaphp/wsdl/"
var serviceurlusu = "http://127.0.0.1/aerolineaphp/operaciones/"

//var serviceurl = "http://vps-974912-x.dattaweb.com/ravsaphp/wsdl/"
//var serviceurlusu = "http://vps-974912-x.dattaweb.com/aerolineaphp/operaciones/"

	//var serviceurlusu = "http://192.168.1.119/aerolineaphp/operaciones/"

function buscarCiudades(donde,ponerEn,idname){
	$.ajaxSetup({
		url:  serviceurl+'ciudadesAW.php',
		global: false,
		type: "POST"
	});
	$.ajax({url: serviceurl+'ciudadesAW.php',
		crossDomain: true,
		data:'html=si&donde='+donde+'&idname='+idname, //{action : 'login', formData : $('#check-user').serialize()},
		type: 'POST',                  
		async: 'true',
		dataType: 'json',
		beforeSend: function() {
			$.mobile.loading('show')
		},
		complete: function() {
			$.mobile.loading('hide')
		},
		success: function (data) {
			//alert(data);
			if(data.estado) {
				$(ponerEn).html(data.ciudades);
				$(ponerEn).trigger("create");
			} else {
				alert('No se consiguio obtener las Ciudades. Verifique su conexion.');
			}
		},
		error: function (request,error) {
			
			alert('No se consiguio obtener las Ciudades. Verifique su conexion.'+request +" "+error);
		}
	});
}

function buscarVuelos(form,ponerEn,salida){
	$.ajax({url: serviceurl+'airAvailRQ.php',
		data:$(form).serialize()+"&donde="+ponerEn,
		async: 'true',
		dataType: 'json',
		type: "POST",
		beforeSend: function() {
			$.mobile.loading('show')
		},
		complete: function(data) {
			$.mobile.loading('hide')
		},
		success: function (data) {
			if(data.estado) {
				//alert(mycircle.r + ' -> ' + mycircle.area());
				if(salida){
					storage.setVuelosSalida(jQuery.parseJSON(data.info));
				} else {
					storage.setVuelosRetorno(jQuery.parseJSON(data.info));
				}
				
				//Storage().arrVueloSalidas = jQuery.parseJSON(data.info);
				$(ponerEn).html(data.vuelos);
				$(ponerEn).trigger("create");
				
			} else {
				errortexto = "Lo sentimos. No se ha encontrado ning�n vuelo disponible con origen en XXX y destino YYY Intente cambiar la fecha de Salida/Retorno."
				alert(errortexto);
			}
			
		},
		error: function (request,error) {
			alert('No se consiguio obtener la Informaci�n. Verifique su conexion.');
		}
	});
	
}

function buscarGrupoFamiliar(form,ponerEn,storage){
	idUsuarioPrincipal = 0;
	if(storage.getIdUsuarioPrincipal()==0 || storage.getIdUsuarioPrincipal()==null){
		idUsuarioPrincipal = storage.getIdUsuarioAModificar();
	}else {
		idUsuarioPrincipal = storage.getIdUsuarioPrincipal();
	}
	
	$.ajax({url: serviceurlusu+'wsusuario.php',
		crossDomain: true,
		data:$(form).serialize()+"&donde="+ponerEn+"&accion=grupofamiliar&idusuario="+idUsuarioPrincipal,
		async: 'true',
		dataType: 'json',
		type: "POST",
		beforeSend: function() {
			$.mobile.loading('show')
		},
		complete: function(data) {
			$.mobile.loading('hide')
		},
		success: function (data) {
			if(data.estado) {
				//alert(mycircle.r + ' -> ' + mycircle.area());
				storage.setIdUsuarioAModificar(data.idusuario);
				storage.setIdUsuarioPrincipal(data.idusuarioprincipal);
				storage.setUsuarioModifica(null);
				
				$( ":mobile-pagecontainer" ).pagecontainer('change', '#usuario_2', {
					reverse: false,
					reload: true
				});
				
				$(ponerEn).html(data.texto);
				$(ponerEn).trigger("create");
				
			} else {
				if(data.texto != '')
					errortexto = data.texto;
				else 
					errortexto = "Lo sentimos. No se ha encontrada informaci�n."
				alert(errortexto);
			}
			
		},
		error: function (request,error) {
			alert('No se consiguio obtener la Informaci�n. Verifique su conexion.');
		}
	});
	
}

function guardarUsuario(form,redireccionar){
	
	$.ajax({url: serviceurlusu+'wsusuario.php',
		crossDomain: true,
		data:$(form).serialize()+"&accion=modifica",
		async: 'true',
		dataType: 'json',
		type: "POST",
		beforeSend: function() {
			$.mobile.loading('show')
		},
		complete: function(data) {
			$.mobile.loading('hide')
		},
		success: function (data) {
			if(data.estado){
				storage.setIdUsuarioAModificar(data.idusuario);
				storage.setIdUsuarioPrincipal(data.idusuarioprincipal);
				storage.setUsuarioModifica(null);
				$( ":mobile-pagecontainer" ).pagecontainer('change',redireccionar , {
					reverse: false,
					reload: true
				});
				if(data.idusuarioprincipal!=null && data.idusuarioprincipal!='' && data.idusuarioprincipal!='null' )
					buscarGrupoFamiliar('#formLogin','#resultadoGrupoFamiliar',storage);
		     	
			} else {
				errortexto = "Lo sentimos. No se pudieron guardar los datos."
				alert(errortexto);
			}
			
		},
		error: function (request,error) {
			alert('No se consiguio obtener la Informaci�n. Verifique su conexion.');
		}
	});
	
}

function buscarUsuario(storage,id){
	resultado = false;
	$.ajax({url: serviceurlusu+'wsusuario.php',
		crossDomain: true,
		data:"accion=darUno"+"&idusuario="+id,
		async: 'true',
		dataType: 'json',
		type: "POST",
		beforeSend: function() {
			$.mobile.loading('show')
		},
		complete: function(data) {
			$.mobile.loading('hide')
		},
		success: function (data) {
			if(data.estado) {
				storage.setIdUsuarioAModificar(id);
				storage.setUsuarioModifica(jQuery.parseJSON(data.info));
				elusu = storage.getUsuarioModifica(id);
				resultado = true;
				storage.setIdUsuarioPrincipal(elusu.idusuarioprincipal);
				
				if(elusu.idusuarioprincipal ==0){
					$( ":mobile-pagecontainer" ).pagecontainer('change', '#usuario_3', {
						reverse: false,
						reload: true
					});
				}else {
					
					$( ":mobile-pagecontainer" ).pagecontainer('change', '#usuario_3adicional', {
						reverse: false,
						reload: true
					});
				}
				
				
			} else {
				errortexto = "Lo sentimos. No se ha encontrada informaci�n."
				alert(errortexto);
			}
			
		},
		error: function (request,error) {
			alert('No se consiguio obtener la Informaci�n. Verifique su conexion.');
		}
	});
	
	return resultado;
	
}


/**
 * PseudoCityCode=NET&ISOCountry=AR&ISOCurrency=USD
 * &ai[0][DepartureDateTime]=2014-09-19 08:00:00&ai[0][ArrivalDateTime]=2014-09-19 08:45:00&ai[0][FlightNumber]=500&ai[0][ResBookDesigCode]=Y&ai[0][DepartureAirport]=CCS&ai[0][ArrivalAirport]=MAR
 * &ai[0][MarketingAirline]=AW
 * &pt[0][PassengerTypeQuantityCode]=ADT&pt[0][PassengerTypeQuantityQuantity]=1
 * @param form
 * @param ponerEn
 * @param salida
 */
function buscarVueloTarifas(page,divsel,form,vueloSel,ponerEn,salida,bbdd){
	var objForm = $(form).formParams();
	parametros = "html=si";
	parametros += "&PseudoCityCode="+objForm.PseudoCityCode+"&ISOCountry="+objForm.ISOCountry+"&ISOCurrency="+objForm.ISOCurrency+"";
	//Agrego los tipos de pasajeros. Arreglar para que tome la cantidad real del formulario
	parametros += "&pt[0][PassengerTypeQuantityCode]="+objForm.PassengerTypeQuantityCode+"&pt[0][PassengerTypeQuantityQuantity]="+objForm.PassengerTypeQuantityQuantity+"";
	//Agrego los vuelos. Arreglar para que soporte mas de un vuelo para el caso de los vuelos no directos
	parametros += "&ai[0][DepartureDateTime]="+vueloSel.DepartureDateTime+"&ai[0][ArrivalDateTime]="+vueloSel.ArrivalDateTime+"&ai[0][FlightNumber]="+vueloSel.FlightNumber+"";
	parametros +="&ai[0][ResBookDesigCode]="+objForm.ResBookDesigCode+"&ai[0][DepartureAirport]="+vueloSel.DepartureAirport+"&ai[0][ArrivalAirport]="+vueloSel.ArrivalAirport+"";
	parametros += "&ai[0][MarketingAirline]="+objForm.MarketingAirline+"";

	$.ajax({url: serviceurl+'airPriceRQ.php',
		data:parametros+"&donde="+ponerEn,
		async: 'true',
		dataType: 'json',
		type: "POST",
		beforeSend: function() {
			$.mobile.loading('show')
		},
		complete: function(data) {
			$.mobile.loading('hide')
		},
		success: function (data) {
			if(data.estado) {
				//alert(mycircle.r + ' -> ' + mycircle.area());
				if(salida){
					bbdd.setVueloSalida(vueloSel);
					bbdd.setVueloSalidaTarifa(jQuery.parseJSON(data.info));
				} else {
					bbdd.setVueloRetorno(vueloSel);
					bbdd.setVueloRetornoTarifa(jQuery.parseJSON(data.info));
				}
				mostrarInformacionVueloSeleccionado(page,divsel,bbdd,salida);
				//$(ponerEn).html(data.vuelos);
				//$(ponerEn).trigger("create");
			} else {
				errorTexto = "�No existen tarifas vigentes para esta configuraci�n, seleccione otra!";
				alert(errorTexto);
			}
			
		},
		error: function (request,error) {
			alert('No se consiguio obtener la Informaci�n. Verifique su conexion.');
		}
	});
	
}


